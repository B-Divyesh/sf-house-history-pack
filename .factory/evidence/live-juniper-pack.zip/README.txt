House History Pack

Open house-history-report.pdf for the portable report. Original evidence files are in /evidence. records.json contains structured data for future import or audit. Keep private: this pack may contain addresses, serial numbers, invoices, and permits.
